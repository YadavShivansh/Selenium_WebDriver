package testDefinition;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import factory.baseClass;
import io.cucumber.java.en.*;
import pageObjects.userInfo;

public class testDef1 extends baseClass{
	
	public WebDriver driver;
	userInfo info;
	Properties p;
	
	
	
	@And("Open the beCognizant portal")
	public void Open_the_be_Cognizant_portal()
	{
		info = new userInfo(baseClass.getDriver());
	}
	
	@When("user clicks on account manager icon")
	public void user_clicks_on_account_manager_icon()
	{
		
		info = new userInfo(baseClass.getDriver());
		info.clickAccIcon();
	}
	
	@Then("it should display valid usermail")
	public void it_should_display_valid_usermail() throws IOException {
		
	
		String user = getProperties().getProperty("user");
		
		String id= info.getUserMail();
//		if(user.equals(id))
//		{
//			System.out.println("Valid User");
//		}
//		else
//		{
//			System.out.println("Invalid User");
//		}
		Assert.assertEquals(user,id,"Invalid User");
		
	}
}