package testDefinition;

import org.openqa.selenium.WebDriver;

import factory.baseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import pageObjects.validateWorldClock;

public class testDef2 {
	
	public WebDriver driver;
	validateWorldClock validWC;
	

@Given("homepage of application")
public void homepage_of_application() {
	validWC= new validateWorldClock(baseClass.getDriver());
}

@When("user scrolls till end of page")
public void user_scrolls_till_end_of_page() {
	
	validWC.scroll();
}
   

@Then("world clock should be displayed")
public void world_clock_should_be_displayed() {
	validWC.getWcText();
    
}

	
	

}
