package testDefinition;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import factory.baseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class hooks {
	WebDriver driver;
	Properties p;
	
	@Before
	public void setup() throws IOException 
	{
		driver = baseClass.initilizeBrowser();
		
		p = baseClass.getProperties();
		driver.get(p.getProperty("appUrl"));
		driver.manage().window().maximize();		
	}
	
	@After
	 public void tearDown(Scenario scenario)
	 {
 		
	       driver.quit(); 
	  }
	
	public void addScreeshot(Scenario scenario)
	{
		if(scenario.isFailed())
		{
			TakesScreenshot ts = (TakesScreenshot)driver;
			byte[] screenshot= ts.getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png",scenario.getName());
		}
	}
}
