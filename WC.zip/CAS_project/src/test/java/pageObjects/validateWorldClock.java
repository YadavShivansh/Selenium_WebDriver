package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class validateWorldClock extends basePage{

	public validateWorldClock(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	WebDriver driver;
	
	
//Locators
	//@FindBy(xpath="//*[@id='vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af']")
	//@FindBy(xpath="//span[@class='fontSizeMedium']//child::strong")
	@FindBy(xpath="//strong[normalize-space()='See all']")
	WebElement worldclock;
	
	@FindBy(xpath="//*[contains(text(), 'World Clock')]")
	WebElement wcText;
	
	//Action methods
	
	public void scroll()
	{	
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",worldclock);
		
	}

	public void getWcText()
	{
		wcText.getText();
	}
}
