package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class userInfo extends basePage
{
		
		
	public userInfo(WebDriver driver) 
		{
			super(driver);
		
		}

		WebDriver driver;

		
		// Locators
		//@FindBy(xpath="//div[@class='_8ZYZKvxC8bvw1xgQGSkvvA==']")
		@FindBy(xpath="//button[@id='O365_MainLink_Me']")
		WebElement managerIcon;
		@FindBy(xpath="//div[@id='mectrl_currentAccount_secondary']")
		WebElement userMail;
		
		
		//Action methods 
		
		public void clickAccIcon()
		{
			managerIcon.click();
		}
		
		public String getUserMail()
		{
			return userMail.getText();
		}

}
