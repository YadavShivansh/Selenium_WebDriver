package Selenium;

public class lec21 {

	public static void main(String[] args) {
		
		//  CSS loacator ---- XPATH
		/*   xpath is a adddress to the element works on the com.sun.org.apache.xalan.internal.xsltc.DOM .class 
			 1.Absolute xpath(FULL xpath)
			 		for eg. "/html/body/div[6]/div[1]/div[2]/div[1]/a/img"
			 	absolute xpath  shows paths from root element i.e Head to  the last destined element
			 		 it shows the step by step full path
			 		 	here div[6] indiates that the elemet is in its perious's 6 div and in that at 1st div tag 
			 		 
			 
			2. Relative Xpath (PARTIAL xpath)
				for eg.   
				
				partical xpath - shows elemt on the basis of attributes present and not stats from the root elemt 
				it start from the node itslef
				it direct jump to the module
				
				***we should prefer relative xpath  bcz in absolute xpath it go theough every tag form root to tatget abd what if the developer done any changees inthe tags the 
				*our xpath will be broaken so to avoid this we use relative xpath****
				
			write your own relative xpath\
				--- //tagname[@atrributename='value']
					eg. //img[@id="val"]
					we can replace tag name by *
					
				
	*/
	}

}
