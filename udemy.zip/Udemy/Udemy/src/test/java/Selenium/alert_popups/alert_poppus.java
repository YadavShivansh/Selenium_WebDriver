package Selenium.alert_popups;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class alert_poppus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		WebDriverWait explicit  =new WebDriverWait(driver,Duration.ofSeconds(10));
		
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
	
		driver.findElement(By.xpath("//button[text()='Click for JS Confirm']")).click();
		//alert is not a webelement it means we cant  USE FINDeLEMENT METHOD 
		// so we use swithto method to switch windo to alert ands its typ is Alert; 
		
		Alert alrtwind = driver.switchTo().alert();
		
		System.out.println(alrtwind.getText());
		
		/// if aler window takes some time to load then we use the explit wait toreducde synch
	//-----Alert aletwind = explicit.until(ExpectedConditions.alertIsPresent());
		
		alrtwind.accept();// to close the window using "ok";
		
		alrtwind.dismiss(); //to close the alert window by "cancel";
		
	
	}
	

}
