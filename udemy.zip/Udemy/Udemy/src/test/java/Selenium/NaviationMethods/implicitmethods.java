package Selenium.NaviationMethods;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class implicitmethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		// just ater the creation of   web driver wew use implicit cammond
		
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // implicit cammond
		
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		 driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		
		/*
		 * implicit wait
----------
Adv:
1) single time/one statement 
2) it will not wait till maximum time if the element is availble
3) Applicable for all the elements bcz we use driver instace to declare 
4) easy to use

Disadvantge:
1) if the time is not suffitient then you will get exception

		 * 	
		 */
	}
}
