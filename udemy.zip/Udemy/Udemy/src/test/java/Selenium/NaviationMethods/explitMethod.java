package Selenium.NaviationMethods;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class explitMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
	
		// decaling the explicit method-- just afer driver declaration
		WebDriverWait mywait = new WebDriverWait (driver,Duration.ofSeconds(10)); 

		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		WebElement user = mywait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
		user.sendKeys("admin");
		
		WebElement pass = mywait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
		pass.sendKeys("Admin123");
		
		/*
1) Conditional based, it will work more effectively.
2) finding element is inclusive
3) it will wait for condition to be true, then consider the time
4) diss...
we need to write multiple statements for multiple elements
		 */
		
	}

	/*
	 * Navigational commands
-----------------
navigate().to(url)   same as driver.get(url)
navigate().forward()
navigate().back()
navigate().refresh()

driver.navigate().to(url);

driver.manage().window().maximize();

"https://www.google.com"   -----> string

URL myurl=new URL("https://www.google.com")

navigate().to(URL) 
    accepts url is URL & Strign format

driver.get()  
	accepts only String format
	boath have same purpose to open the url but the diffence is in how they functions navaigat.to.url() coamond 
	 accept url in both url and string farmate then call the get method inside if the url is only string then direct calll an
	 if it is in URL fomate the first covert to string then call it.

	 * 
	 * 
	 */
}
