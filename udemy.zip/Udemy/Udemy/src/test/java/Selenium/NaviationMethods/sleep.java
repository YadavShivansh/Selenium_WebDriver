package Selenium.NaviationMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class sleep {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
			WebDriverManager.chromedriver().setup();
			
			WebDriver driver = new ChromeDriver();
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			
			Thread.sleep(5000);
	
			/*
			 wait commands


wait statements will be used to solve synchronization problem in automation.


Thread.sleep(ms)

implicit wait
explicite wait/ fluent state

sleep() : provided by java itself( not selenium command)
------------
Adv:
1) easy to use

DisAdvantage:

1) if the time is not suffitient then you will get exception
2) it will wait ofr maximum time out. this will reduce the perforemce script.
3) multiple times 
 */
			
			driver.findElement(By.name("username")).sendKeys("admin");
	}

}
