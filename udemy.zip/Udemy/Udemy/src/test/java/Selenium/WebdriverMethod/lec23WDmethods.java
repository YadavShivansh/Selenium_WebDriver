package Selenium.WebdriverMethod;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lec23WDmethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");// doesnot retuern any value
		
		driver.getTitle();// get tghe title of the web page retuern Strig
			System.out.println("Title" +driver.getTitle());
		
		driver.getCurrentUrl(); // get the current url used for validation  and return string
		System.out.println("current page "+driver.getCurrentUrl());
		driver.getWindowHandle();
		
		System.out.println("Window " +driver.getWindowHandle());// it return the dynamicalyy unique id to the window rerturn srting 
		// to switch the  driver to different browser windos and to operation s we need window ids
		
		driver.findElement(By.linkText("About")).click();//opens new broweser windows
		
		Set<String> Windowids =driver.getWindowHandles();
			// this returns the list of aal the windows id and it is set of string type ;
		for(String winid:Windowids)
		{
			System.out.println(winid);
		}
		//getwindohandels() is use to get mu;tiple window handels;
			
			/*when we open new window using  driver then it just open it and stick to the previous window i we cant change anyting on secomd wndow
			 * so to do that we use window  handels for switchingg;
			 retuern at th rin time; we dont use it for validation 
			 */
	
	//------------------coditionals Methods-----------
		/*these methods are acesse only by the webEleemnt not by the driver insttance or class and returns boolean value
		 * 	
		 */
		
		
	}

}
