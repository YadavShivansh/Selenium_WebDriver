package Selenium.WebdriverMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class conditionalMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		
		//1.isDisplayed - it cheaks whether the element is prsent on the web page or not 
		
		WebElement logo = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
		boolean status = logo.isDisplayed();
		System.out.println(status);
		
		//2. isEnabled -- it used to cheak is the link aor tag, dropdown is acive or not 
		WebElement searchbox = driver.findElement(By.xpath("//input[@id='small-searchterms']"));
		boolean Dstas = searchbox.isEnabled();
		//System.out.println(Dstas);
		
		//3.isSelcted();
		
			
		WebElement male = driver.findElement(By.id("gender-male"));
		WebElement female = driver.findElement(By.id("gender-female"));
			// b/4 selection
		System.out.println(male.isSelected());
		System.out.println(female.isSelected());
		System.out.println("after selection");
			male.click();
			System.out.println(male.isSelected());
			System.out.println(female.isSelected());
		
		Thread.sleep(5000);
		
	driver.close(); // it closees only the browser  first bcz diver is only openeing the sendow window but it focuses only on the fist browser
	  
	 // driver.quit() ;;;is able to close all the browser opned by the driver
		
		
	}

}
