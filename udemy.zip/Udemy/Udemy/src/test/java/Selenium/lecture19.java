package Selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lecture19 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com");
		driver.manage().window().maximize(); //maximaize the browser
	
	
	
		// search box 
		//driver.findElement(By.id("search_product")).sendKeys("T-shirts"); 
				//we have send keys bcz it is a input method tag
		
		// search button
			//driver.findElement(By.id("submit_search")).click(); //bcz itd button tag
			
			/* Linktext and Partical LinkText is only used for the links 
				for links anankarc tag is <A> to identify the links it is the text on the link we use 
				it bcz we dont have class name like things in link			
		   
	*/
		
		
			//driver.findElement(By.linkText("POLO")).click();
			   ///driver.findElement(By.partialLinkText("Video")).click();
			
			
			/*classname and Tagname is used  to identify multible web element like find aal the link in the page  , find all the images , find all the slids etc
			 * we use findElemnts calss
			  so we need to find out the common locator for all the lements
			  */
			
			 List<WebElement>photos=driver.findElements(By.className("col-sm-6")); // we use list bcz it retuns more than on elwmwnt of type webelement
			 
			 System.out.println("nuber of slides "+photos.size());
				
		List<WebElement>image = driver.findElements(By.tagName("img")); // we use tag name bcz in imgae only tag name is common
		System.out.println("nuber of IMG "+image.size());
	}

}
