package Selenium.handel_dropdown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class handeDropdown2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.jquery-az.com/boots/demo.php?ex=63.0_2");
		
	//clicking the dropdown
		//driver.findElement(By.xpath("//buttons[contains(@class,'multiselect')]")).click();
		driver.findElement(By.xpath("//button[contains(@class,'multiselect')]")).click();
		
	//select the options
		//List <WebElement> options = driver.findElements(By.xpath("//ul[contains(@class ,multiselect)]//label"));
		
		List<WebElement> options =  driver.findElements(By.xpath("//ul[contains(@class,multiselect)]//label"));
		System.out.println(options.size());
		for(WebElement opt :options)
		{
			//System.out.println(opt.getText());
			//for selecting the options
			String text=opt.getText();
			if(text.equals("Java") || text.equals("Python"))
			{
				opt.click();
			}
		}
	
		
	
	}

}
