package Selenium.handel_dropdown;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class dynamic_drp {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://google.com");
		
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("msd");
		
		Thread.sleep(3000);
		
		List<WebElement> options = driver.findElements(By.xpath("//div[@class='wM6W7d']//span"));
		
		for(WebElement lt :options)
		{
			System.out.println(lt.getText());
			if(lt.getText().equals("MS Dhoni"))
			{
				lt.click();
				 break;
			}
				
			
		}
		
	}
	
}
