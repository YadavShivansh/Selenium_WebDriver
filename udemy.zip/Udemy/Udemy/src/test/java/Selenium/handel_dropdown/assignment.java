package Selenium.handel_dropdown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		//./driver.manage().timeouts().implicitlyWait(Duraction.ofScodn)
		driver.findElement(By.xpath("//select[@id='country']")).click();
		
		
		List<WebElement> drpdown = driver.findElements(By.xpath("//select[contains(@class,'form')]//option"));
		
		for(WebElement opt:drpdown)
		{
			//System.out.println(drpdown.size());
			String txt = opt.getText();
			System.out.println(txt);
			if(txt.equals("India"))
			{
				opt.click();
				break;
			}
		}
		
		
		
	}

}
