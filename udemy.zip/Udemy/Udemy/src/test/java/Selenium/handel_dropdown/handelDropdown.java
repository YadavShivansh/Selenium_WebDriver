package Selenium.handel_dropdown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class handelDropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		//1 . DropDown with Select Tag in DOM //select[@id='country']
			//---use "select" class obj
		
		WebElement dropdown = driver.findElement(By.xpath("//select[@id='country']"));
	//after selecting the dropdown we have select all the options 
		//for that we use Select class obj
		
	Select drpoption = new Select(dropdown);
		//1..Selecting an option from the dropdown
	
	 drpoption.selectByVisibleText("India");
	//or drpoption.selecByValue() ... use only when value tag is availabel;
	 
	
// 2.find the total number of options available
	 
	 List<WebElement>option = drpoption.getOptions();
	 
	 System.out.println("size:" +option.size());
	 
	for(int i =0 ; i<option.size();i++)
	{
	///	System.out.println(option.get(i).getText());
		//we have to se getText method bcz get(i) return teh webElements not the text;
	}
		
	for(WebElement opt:option)
	{
		System.out.println(opt.getText());
		//we have to se getText method bcz get(i) return teh webElements not the text;
	}
		
		
	}

}
