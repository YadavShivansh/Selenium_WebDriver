package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lec20 {

	public static void main(String[] args) {
		
	//---Customised Locator---- we combine two or more attributes to make it unique
		/* CSS Locator
		       different combination are 
		       		tag--id - #
		       		tag--class - .
		       		tag--attirbutes -  []
		       		tag--class-atribute -  .[]
		       		
		 */
		 WebDriverManager.chromedriver().setup();
		 WebDriver driver = new ChromeDriver();
		 
		 driver.get("https://demo.nopcommerce.com/");
		 driver.manage().window().maximize();
		 //css selector with tag - id;
		         // driver.findElement(By.cssSelector("input#small-searchterms")).sendKeys("MacBook");
		//css selectoe  with #id
		     //driver.findElement(By.cssSelector("#small-searchterms")).sendKeys("Windows");
		 
		 //tag and claas
		 	//driver.findElement(By.cssSelector("input.search-box-text ")).sendKeys("android");
		 
		//similar;y for tag and attribute
		 		// -- tag[atribute]
		 	// and tag-class - atrribute
		 			// -- tag.calss[atrribute]
		 //sometimmes class didnt get access the you have to delete text after space
		 
		
		 
	}

}
