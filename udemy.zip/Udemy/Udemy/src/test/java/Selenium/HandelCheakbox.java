package Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandelCheakbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		// select specific one cheak box
		    //driver.findElement(By.xpath("//input[@id='sunday']")).click();
		
		// To selct multiple cheak box we use collections ()list strore all webelemt than 
		// cheak for every element
		
//count of cheakbox
		
		List<WebElement>cheakbox=driver.findElements(By.xpath("//input[@class='form-check-input'and@type='checkbox']"));
		
		//now after stroting we have to cheak all to cheak box for that we use loops
		/*
		for(WebElement m:cheakbox)
		{
			m.click();
		}
		*/
		
		//select last 2 cheak box
		
		for(int i = cheakbox.size()-2 ;i<cheakbox.size(); i++)
		{
			cheakbox.get(i).click();
		}
		//simmiary for 1st 2 or last 3 using loop
		
	//	to unselect the cheak box we just have to write code to select the cheak box two time bcz on clicking again the selelcted cheak box it will
		// be unseelscted
		
		
	}

}
