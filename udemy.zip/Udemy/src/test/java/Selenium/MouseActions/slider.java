package Selenium.MouseActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class slider {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		
	    driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		
	    Actions act = new Actions(driver);
	    
	    /// MIN Slider
	    
	    WebElement min_slider=driver.findElement(By.xpath("//span[1]")); 
	    System.out.println("Current location of min slider:"+min_slider.getLocation());  //(59, 250) x,y
	    act.dragAndDropBy(min_slider, 100, 125).perform(); // add 100 to the pricveios
	    System.out.println("Location of min slider After moving:"+min_slider.getLocation());  
 // Max Slider
	  
	    WebElement max_slider=driver.findElement(By.xpath("//span[2]"));
		System.out.println("Current location of max slider:"+max_slider.getLocation());
		
		act.dragAndDropBy(max_slider, -110, 125).perform(); // reduce slider by -100
		System.out.println("Location of max slider after moving:"+max_slider.getLocation());  
	}

}
