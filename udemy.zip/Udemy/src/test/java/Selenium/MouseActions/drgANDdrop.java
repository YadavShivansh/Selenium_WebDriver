package Selenium.MouseActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class drgANDdrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		WebDriverManager.chromedriver().setup();
		WebDriver driver =new ChromeDriver();
		
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
		
		Actions act = new Actions(driver);
		
		// from drag and drop we HAVE TO select the "source" and "taget " elements then use action class
		
		WebElement source=driver.findElement(By.xpath("//div[@id='box6']"));
		WebElement target=driver.findElement(By.xpath("//div[@id='box106']"));
		
		act.dragAndDrop(source, target).perform();
		
		// Wasington---> USA
				WebElement washington=driver.findElement(By.xpath("//div[@id='box3']"));
				WebElement usa=driver.findElement(By.xpath("//div[@id='box103']"));
				
				act.dragAndDrop(washington, usa).perform();
		
	}

}
