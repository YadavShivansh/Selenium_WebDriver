package Selenium.frames;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class windowsswitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 * to switch b/w windoe=ws we have to use the windo id 
		 * we get window id by methdo
		 * 
		 */
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	 
		 
		 driver.findElement(By.xpath("//a[normalize-space()='OrangeHRM, Inc']")).click();
		 //to switch 
		 	//capture the id's from the windows;
		 
		 		Set<String>winIds=driver.getWindowHandles(); // strol all open wimdows id in set bcz its return tpe is set;
		 		    // in s
		 		//in set we cant iterate using get or any method so we have to use ethire
		 		
		 //approch 1. conveert set to List
/*
		 		
		 			List<String>winidlt = new ArrayList(winIds);//converted
		 			  
		 			String parent = winidlt.get(0);
	 			String child = winidlt.get(1);
		 			
          //	 	switch to child window
	 			
	 			driver.switchTo().window(child);
	 			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[2]/a/button")).click();
		 	
	 		//switch to parent window
	 			driver.switchTo().window(parent);
	 			driver.findElement(By.name("username")).sendKeys("admin");
	 		
	 	//we can use this approch only when we have lesss windows		
		 	*/
		 	
	//approach 2;
		 	for(String winId: winIds)
		 	{
		 		String  title = driver.switchTo().window(winId).getTitle();
		 		if(title.equals("OrangeHRM HR Software | OrangeHRM"))
		 			
		 		{
		 			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[2]/a/button")).click();
				 	
		 		}
		 	}
		 		
		/*to close the window we use 
		 * close() and quit() repectively for closing the current window and all the windos
		 * 
		 *  and for closing the specific windows  we use for loop along with th titlle if title matvhes then close just like
		 *  aporach 2
		 * 
		 *  		
		 */
		 		
		 	/*for(String winid:windowIDs)
			{
				String title=driver.switchTo().window(winid).getTitle();
				
				if( title.equals("x") || title.equals("y") || title.equals("z"))
				{
					driver.close();
				}
			}*/
			
			
			for(String winid:winIds)
			{
				String title=driver.switchTo().window(winid).getTitle();
				
				if( title.equals("OrangeHRM HR Software | Free & Open Source HR Software | HRMS | HRIS | OrangeHRM"))
				{
					driver.close();
				}
			}
		 	
	}

}
