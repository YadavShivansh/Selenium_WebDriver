package Selenium.frames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class frames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		 driver.get("https://ui.vision/demo/webtest/frames/");
		 
		  driver.switchTo().frame("name/id");
		  /*
		   * we use three types
		   * 1. driver.switchTo().frame(name/id);
		   * 2.driver.switchTo().frame(WebEleemnt);
		   * 3. driver.switchTo().frame(index);
		   * 
		   * 	   */
		  
		driver.findElement(By.name("mytext1")).click();//frame 1
		
		/*after switch to the 1st frame the driver is stick to the 1st frame 
		 * means we cant directly move/switch the driver from frame to frame
		 * so for this we have to move back  the driver to the mmain page then 
		 * switch it to the 2nd frsme
		 * 
		 */
		
		driver.switchTo().defaultContent(); //switch back to the main page
		
		//driver.switchTo().frame("name/id");// now switch to the 2nd frsme;
	driver.switchTo().frame("frma2");
	
		driver.findElement(By.name("mytext2")).click();// frmae 2
		
		driver.switchTo().defaultContent();//again switch to the main page;
	driver.switchTo().frame("sdf3");	
		driver.findElement(By.name("mytext3")).click();// frmae 3;
		

	}

	
}
