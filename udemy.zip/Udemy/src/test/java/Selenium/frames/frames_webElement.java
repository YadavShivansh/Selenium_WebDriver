package Selenium.frames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class frames_webElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		 driver.get("https://ui.vision/demo/webtest/frames/");
//frame s webelement;
		 
		 WebElement frm1 = driver.findElement(By.xpath("//frame[@src='frame_1.html']"));
		 driver.switchTo().frame(frm1);
		driver.findElement(By.xpath("//input[@name='mytext1']")).sendKeys("rre");
	/*
	 * 1.capture the frame webeleemnt
	 * 2.switxch to the fram 
	 * 3. perfrom action
	 * 
	 */
		
	driver.switchTo().defaultContent(); // setting driver to main
	//frame 2
		  WebElement frm2 = driver.findElement(By.xpath("//frame[@src='frame_2.html']"));
	 	  driver.switchTo().frame(frm2);
	 	  driver.findElement(By.name("mytext2")).sendKeys("msd");
		 
	driver.switchTo().defaultContent();
	/*	
		WebElement frm3 =driver.findElement(By.xpath("frame[@src='frame_3.html']"));
		driver.switchTo().frame(frm3);
		driver.findElement(By.xpath("//input[@name='mytext3']")).sendKeys("msd");
	*/	
		WebElement frm3=driver.findElement(By.xpath("//frame[@src='frame_3.html']"));
		driver.switchTo().frame(frm3);
		driver.findElement(By.xpath("//input[@name='mytext3']")).sendKeys("33333");
		//inner frame [frame inside a frame for that we dont have to move the defalul  page we can just switch to the inner frame;
			
		driver.switchTo().frame(0); //we can use index 0 bcz ther is only one inner frame avail able;
		driver.findElement(By.cssSelector("div.AB7Lab")).click();
		
		 
		

	}

}
