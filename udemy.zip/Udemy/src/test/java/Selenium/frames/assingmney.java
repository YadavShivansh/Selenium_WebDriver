package Selenium.frames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class assingmney {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://the-internet.herokuapp.com/iframe");
		WebElement frm  = driver.findElement(By.xpath("//iframe[@id='mce_0_ifr']"));
		driver.switchTo().frame(frm);
		WebElement txt = driver.findElement(By.xpath("//*[@id=\"tinymce\"]/p"));
		txt.clear();
		txt.sendKeys("this is selenium");
		
	driver.close();	
			
	Thread.sleep(3000);
	

	}

}
