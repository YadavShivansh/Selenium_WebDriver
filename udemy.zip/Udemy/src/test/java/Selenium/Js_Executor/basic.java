package Selenium.Js_Executor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		//ChromeDriver driver=new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		driver.switchTo().frame(0);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		// First name -- inpuut box
		WebElement inputb = driver.findElement(By.id("RESULT_TextField-1"));
		
		js.executeScript("argument[0].setAttribut('value','john') " , inputb);
		
	//radio buton
		WebElement male_Rd=driver.findElement(By.id("RESULT_RadioButton-7_0"));
		js.executeScript("arguments[0].click()", male_Rd);
	
	//Checkbox
		WebElement chkbox=driver.findElement(By.id("RESULT_CheckBox-8_0"));
		js.executeScript("arguments[0].click()", chkbox);
		
	//button
		WebElement button=driver.findElement(By.id("FSsubmit"));
		js.executeScript("arguments[0].click()", button);
		
	}

}
