package com.mini;

import org.openqa.selenium.WebElement;

public class printCount{

	public static String count(WebElement wb) {
		
		// TODO Auto-generated method stub
		String result = wb.getText();
		String res[] =result.split(" ");
		
		//System.out.println("Count" +res[1]);
		return res[1];

	}

}
