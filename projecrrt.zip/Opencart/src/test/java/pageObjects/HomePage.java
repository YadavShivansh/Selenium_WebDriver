package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

// thsi Home poage contains only two action  Clicking RESTRATION AND ACCOUNT
public class HomePage extends BasePage
{
	WebDriver driver;
	
	public HomePage(WebDriver driver)
	{
		super(driver); //  directs to the constructor of the base page
	}
	
 // Locators
	
	@FindBy(xpath="//a[normalize-space()='Register']")
	WebElement lnkRegister;
	@FindBy(xpath="//span[normalize-space()='My Account']")
	WebElement lnkMyaccount;
	
 //Action Method
	
	public void clickMyAccount()
	{
		lnkMyaccount.click();
	}
	
	public void clickRegister()
	{
		lnkRegister.click();
	}
}
